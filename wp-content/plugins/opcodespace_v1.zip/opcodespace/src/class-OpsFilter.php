<?php 
/**
* 
*/
class OpsFilter
{
	
	public static function init()
	{
		$self = new self;
        //add_filter('manage_pfm_registration_posts_columns', array($self, 'pfmRegistrationTableHead'));
	}
}
 ?>