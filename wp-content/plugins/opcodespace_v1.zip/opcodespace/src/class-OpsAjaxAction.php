<?php 
/**
* 
*/
class OpsAjaxAction
{
	
	static public function init()
	{
		$self = new self();
		//add_action( "wp_ajax_delete_source_pdf_forms", array($self, 'test') );
		//add_action( "wp_ajax_nopriv_linked_banks", array($self, '') );
	}


	public function test()
	{
		# code...

		wp_send_json_success(['test' => 'done']);
	}


}
 ?>