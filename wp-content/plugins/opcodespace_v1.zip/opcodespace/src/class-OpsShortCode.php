<?php 
/**
* 
*/

class OpsShortCode
{

	public static function init()
	{
		$self = new self;
		add_shortcode( 'example',array($self, 'example') );
	}
	
	public function ViewEvents() {
		return get_view(OP_VIEW_PATH . "content-dropbox-callback.php", compact('var'));
	}

	
}
 ?>